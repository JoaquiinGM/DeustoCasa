<?php include('template/header.php'); ?>

<div class="container">
          <div class="row">
              <div class="col-md-12">
              <div class="jumbotron">
              <h1 class="display-3">Bienvenido <?php echo $username ?></h1>
              <p class="lead">Has entrado en el modo administrador de viviendas</p>
              <hr class="my-2">
              <p>More info</p>
              <p class="lead">
              <a class="btn btn-primary btn-lg" href="./sections/viviendas.php" role="button">ADMINISTRAR</a>
          </p>
      </div>