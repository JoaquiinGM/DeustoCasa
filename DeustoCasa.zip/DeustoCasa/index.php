<?php include("./template/header.php"); ?>

<link rel="stylesheet" href="./css/styles.css">

<div class="jumbotron text-center centrado">
        <h1 class="display-3">Bienvenido a DeustoCasa</h1>
        <p class="lead">Tu buscador de viviendas preferido</p>
        <hr class="my-2">
        <p class="lead">
            <a class="btn btn-primary btn-lg" href="./viviendas.php" role="button">BUSCAR</a>
        </p>
    </div>